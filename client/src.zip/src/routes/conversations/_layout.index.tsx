import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/conversations/_layout/")({
  component: () => null,
});
