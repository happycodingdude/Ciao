export const isPhoneScreen = () => window.innerWidth < 768;
