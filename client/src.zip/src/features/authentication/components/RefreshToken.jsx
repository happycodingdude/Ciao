import React from "react";
import Loading from "../../../components/Loading";

const RefreshToken = () => {
  // const { data: info } = useInfo(true);
  // const [refreshToken] = useLocalStorage("refreshToken");

  // if (!refreshToken) {
  //   return "need to refresh";
  // }

  return <Loading />;
};

export default RefreshToken;
