import { Outlet } from "@tanstack/react-router";

export function AuthLayout() {
  return <Outlet />;
}
