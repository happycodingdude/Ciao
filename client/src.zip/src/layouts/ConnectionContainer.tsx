import React from "react";

const ConnectionContainer = () => {
  return <></>;
};

export default ConnectionContainer;
